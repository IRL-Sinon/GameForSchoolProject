package logic;

public enum Controls {
    RIGHT, LEFT, JUMP, STOP, SPIND_DASH
}
