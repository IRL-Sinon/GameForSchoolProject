package logic;

public class Enemy {
}
