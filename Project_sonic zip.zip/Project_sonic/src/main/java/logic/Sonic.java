package logic;

import javax.swing.*;
import java.awt.*;

public class Sonic {
    private int x;
    private int y;
    private int width;
    private int height;
    private Image image;
    private boolean facingRight = true;

    public Sonic(int x, int y, String url) {
        this.x = x;
        this.y = y;

        ImageIcon ii = new ImageIcon(url);
        this.image = ii.getImage();
        this.width = ii.getIconWidth();
        this.height = ii.getIconHeight();
    }

    public void move(int dx, int dy) {
        x += dx;
        y += dy;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(String url) {
        ImageIcon ii = new ImageIcon(url);
        this.image = ii.getImage();
    }

    public boolean isFacingRight() {
        return facingRight;
    }

    public void setFacingRight(boolean facingRight) {
        this.facingRight = facingRight;
    }
}
