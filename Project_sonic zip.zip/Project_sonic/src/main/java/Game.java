

import javax.swing.*;

public class Game {
    private GameLogic logic;
    private GameGraphics graphics;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Game game = new Game();
            game.start();
        });
    }

    public Game() {
        this.logic = new GameLogic();
        this.graphics = new GameGraphics(logic);
    }

    public void start() {
        Timer timer = new Timer(16, e -> {
            logic.update();
            graphics.repaint();
        });
        timer.start();
    }
}
