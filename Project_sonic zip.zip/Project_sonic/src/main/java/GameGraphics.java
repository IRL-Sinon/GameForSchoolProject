

import logic.Controls;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GameGraphics extends JFrame {
    private GameLogic logic;
    private boolean jumping = false;


    public GameGraphics(GameLogic logic) {
        this.logic = logic;

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Project Sonic");
        setIconImage(new ImageIcon("src/main/resources/sonic icon.png").getImage());

        GamePanel gamePanel = new GamePanel();
        add(gamePanel);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT:
                        logic.moveSonic(Controls.LEFT);
                        break;
                    case KeyEvent.VK_RIGHT:
                        logic.moveSonic(Controls.RIGHT);
                        break;
                    case KeyEvent.VK_SPACE:
                        startJump();
                        break;
                    case KeyEvent.VK_ESCAPE:
                        System.exit(0);
                        break;
                }
            }
        });

        setVisible(true);
    }

    private void startJump() {
        if (!jumping) {
            jumping = true;
        }
    }

    private class GamePanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int width = 100;
            int height = 100;
            Image sonicImage = logic.getSonic().getImage();

            if (logic.getSonic().isFacingRight()) {
                g.drawImage(sonicImage, logic.getSonic().getX(), logic.getSonic().getY(), width, height, null);
            } else {
                g.drawImage(sonicImage, logic.getSonic().getX() + width, logic.getSonic().getY(), -width, height, null);
            }
        }
    }
}
