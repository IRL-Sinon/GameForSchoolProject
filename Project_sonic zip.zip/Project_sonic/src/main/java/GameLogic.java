import logic.Controls;
import logic.Sonic;

public class GameLogic {
    private Sonic sonic;
    private double Speed = 1;
    private final double MAX_SPEED = 100;
    private final double ACCELERATION = 0.1;
    private final double DECELERATION = 10;

    public GameLogic() {
        this.sonic = new Sonic(400, 300, "src/main/resources/Walking/sonic walking15.png");
    }

    public void moveSonic(Controls control) {
        switch (control) {
            case LEFT:
                if (Speed > 0) {
                    Speed -= DECELERATION;
                    if (Speed < 0) {
                        Speed = 0;
                    }
                } else {
                    Speed -= ACCELERATION;
                    if (Speed < -MAX_SPEED) {
                        Speed = -MAX_SPEED;
                    }
                }
                sonic.move((int) Speed, 0);
                sonic.setFacingRight(false);
                break;
            case RIGHT:
                if (Speed < 0) {
                    Speed += DECELERATION;
                    if (Speed > 0) {
                        Speed = 0;
                    }
                } else {
                    Speed += ACCELERATION;
                    if (Speed > MAX_SPEED) {
                        Speed = MAX_SPEED;
                    }
                }
                sonic.move((int) Speed, 0);
                sonic.setFacingRight(true);
                break;
            case STOP:
                if (Speed > 0) {
                    Speed -= DECELERATION;
                    if (Speed < 0) {
                        Speed = 0;
                    }
                } else if (Speed < 0) {
                    Speed += DECELERATION;
                    if (Speed > 0) {
                        Speed = 0;
                    }
                }
                sonic.move((int) Speed, 0);
                break;
            //case JUMP
            //implementace skoku
            //break

            //case SPIN_DASH
            //implementace aby se SPIN_DASH spouštěl pouze když hrác dá šipku dolů během pohybu postavy
            //break
        }
    }

    public void update() {
    }

    public Sonic getSonic() {
        return sonic;
    }
}
